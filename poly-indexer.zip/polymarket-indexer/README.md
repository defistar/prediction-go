# Polymarket Indexer 🔮

A production-grade blockchain indexer for Polymarket prediction markets on Polygon. Built with Go, following battle-tested patterns from eth-tracker and evm-scanner.

## Features

- ⚡ **High Performance** - Process 10k+ blocks/min with <50MB RAM
- 🔄 **Real-time + Historical** - WebSocket subscription + backfill
- 📨 **NATS JetStream** - Deduplication & persistent messaging
- 📊 **TimescaleDB** - Time-series data with hypertables
- 🛡️ **Production Ready** - Reorg handling, multi-RPC failover, graceful shutdown
- 🎯 **Event-Driven** - CTF Exchange orders, token transfers, market events

## Architecture

```
┌─────────────────────────────────────────┐
│  Polygon RPC (Multi-endpoint failover)  │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│  Syncer (Real-time + Backfill)          │
│  - WebSocket subscription               │
│  - Checkpoint management                │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│  Processor (Worker Pool)                │
│  - Decode events via ABI                │
│  - Filter by contract addresses         │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│  Event Router & Handlers                │
│  - OrderFilled, OrderCancelled          │
│  - TransferSingle, TransferBatch        │
│  - MarketCreated                        │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│  NATS JetStream (Deduplication)         │
│  Subject: POLYMARKET.{Event}.{Contract} │
└─────────────────────────────────────────┘
              ↓
┌─────────────────────────────────────────┐
│  Consumer → TimescaleDB                 │
│  - Event storage (hypertable)           │
│  - Aggregations (volume, trades)        │
└─────────────────────────────────────────┘
```

## Contracts (Polygon Mainnet)

| Contract | Address | Deployment Block |
|----------|---------|------------------|
| CTF Exchange | `0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E` | 20,558,323 |
| Conditional Tokens | `0x4D97DCd97eC945f40cF65F87097ACe5EA0476045` | 7,534,294 |
| USDC (Collateral) | `0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174` | - |

## Quick Start

### Prerequisites

- Go 1.21+
- Docker & Docker Compose
- Polygon RPC endpoint (public or private)

### 1. Clone and Setup

```bash
git clone <your-repo>
cd polymarket-indexer

# Copy and configure
cp config.toml.example config.toml
nano config.toml  # Add your Polygon RPC endpoint
```

### 2. Start Dependencies (NATS + TimescaleDB)

```bash
docker-compose up -d nats timescaledb
```

### 3. Build and Run Indexer

```bash
make build
./bin/indexer

# Or with Docker
make docker-build
docker-compose up indexer
```

### 4. Run Consumer

```bash
./bin/consumer

# Or
docker-compose up consumer
```

## Configuration

See `config.toml` for all options:

```toml
[chain]
rpc_endpoint = "https://polygon-rpc.com"
ws_endpoint = "wss://polygon-rpc.com"
chainid = 137
start_block = 20558323  # CTF Exchange deployment

[contracts]
ctf_exchange = "0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E"
conditional_tokens = "0x4D97DCd97eC945f40cF65F87097ACe5EA0476045"
usdc = "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174"

[jetstream]
endpoint = "nats://localhost:4222"
persist_duration_hrs = 168  # 7 days

[timescaledb]
dsn = "postgres://user:pass@localhost:5432/polymarket"
```

## Project Structure

```
polymarket-indexer/
├── cmd/
│   ├── indexer/          # Main indexer service
│   └── consumer/         # NATS → TimescaleDB consumer
├── internal/
│   ├── chain/            # Multi-RPC client
│   ├── syncer/           # Block syncing (real-time + backfill)
│   ├── processor/        # Event processing
│   ├── cache/            # Address filtering
│   ├── router/           # Event routing
│   ├── handler/          # Event handlers
│   ├── nats/             # NATS publisher/consumer
│   └── db/               # Database (TimescaleDB + BoltDB)
├── pkg/
│   ├── models/           # Domain models
│   └── contracts/        # ABIs + Go bindings
├── migrations/           # SQL migrations
├── docker-compose.yml
└── Makefile
```

## Events Indexed

### CTF Exchange (`0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E`)

- `OrderFilled` - Trades executed
- `OrderCancelled` - Orders cancelled
- `OrdersMatched` - Order matching
- `TokenRegistered` - New market tokens

### Conditional Tokens (`0x4D97DCd97eC945f40cF65F87097ACe5EA0476045`)

- `TransferSingle` - Single token transfer
- `TransferBatch` - Batch token transfer
- `ConditionPreparation` - New condition/market
- `ConditionResolution` - Market resolution
- `PositionSplit` - Position minting
- `PositionsMerge` - Position redemption

## Development

### Generate Contract Bindings

```bash
make generate-bindings
```

### Run Tests

```bash
make test
```

### Lint

```bash
make lint
```

## Monitoring

### Health Check

```bash
curl http://localhost:8080/health
```

### Metrics (Prometheus)

```bash
curl http://localhost:8080/metrics
```

### Stats

```bash
curl http://localhost:8080/stats
```

## Production Deployment

See `docs/DEPLOYMENT.md` for production deployment guide including:
- Multi-RPC setup
- Kubernetes manifests
- Monitoring & alerting
- Backup strategies

## Contributing

Contributions welcome! Please see `CONTRIBUTING.md`.

## License

MIT

## Acknowledgments

Built on patterns from:
- [eth-tracker](https://github.com/grassrootseconomics/eth-tracker) - NATS integration
- [evm-scanner](https://github.com/84hero/evm-scanner) - RPC resilience

---

**Built with ❤️ for prediction markets**
