// Package syncer coordinates blockchain synchronization.
package syncer

import (
	"context"
	"fmt"
	"sync"
	"time"

	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
	"github.com/rs/zerolog"

	"github.com/0xkanth/polymarket-indexer/internal/chain"
	"github.com/0xkanth/polymarket-indexer/internal/db"
	"github.com/0xkanth/polymarket-indexer/internal/processor"
)

var (
	syncerHeight = promauto.NewGauge(prometheus.GaugeOpts{
		Name: "polymarket_syncer_block_height",
		Help: "Current block height being processed",
	})

	chainHeight = promauto.NewGauge(prometheus.GaugeOpts{
		Name: "polymarket_chain_block_height",
		Help: "Latest block height on chain",
	})

	blocksBehind = promauto.NewGauge(prometheus.GaugeOpts{
		Name: "polymarket_blocks_behind",
		Help: "Number of blocks behind chain head",
	})

	syncerErrors = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "polymarket_syncer_errors_total",
		Help: "Total number of syncer errors",
	}, []string{"error_type"})
)

// Syncer coordinates blockchain synchronization.
type Syncer struct {
	logger        zerolog.Logger
	chain         *chain.Client
	processor     *processor.Processor
	checkpoint    *db.CheckpointStore
	serviceName   string
	startBlock    uint64
	batchSize     uint64
	pollInterval  time.Duration
	confirmations uint64
	workers       int
	mu            sync.RWMutex
	currentBlock  uint64
	latestBlock   uint64
	isHealthy     bool
}

// Config holds syncer configuration.
type Config struct {
	ServiceName   string        // Service identifier for checkpoint
	StartBlock    uint64        // Block to start syncing from
	BatchSize     uint64        // Number of blocks to process in one batch
	PollInterval  time.Duration // How often to poll for new blocks
	Confirmations uint64        // Number of confirmations before processing
	Workers       int           // Number of parallel workers for backfill
}

// New creates a new syncer.
func New(
	logger zerolog.Logger,
	chain *chain.Client,
	processor *processor.Processor,
	checkpoint *db.CheckpointStore,
	cfg Config,
) *Syncer {
	return &Syncer{
		logger:        logger.With().Str("component", "syncer").Logger(),
		chain:         chain,
		processor:     processor,
		checkpoint:    checkpoint,
		serviceName:   cfg.ServiceName,
		startBlock:    cfg.StartBlock,
		batchSize:     cfg.BatchSize,
		pollInterval:  cfg.PollInterval,
		confirmations: cfg.Confirmations,
		workers:       cfg.Workers,
		isHealthy:     true,
	}
}

// Start begins synchronization.
func (s *Syncer) Start(ctx context.Context) error {
	s.logger.Info().Msg("starting syncer")

	// Get or create checkpoint
	checkpoint, err := s.checkpoint.GetOrCreateCheckpoint(ctx, s.serviceName, s.startBlock)
	if err != nil {
		return fmt.Errorf("failed to get checkpoint: %w", err)
	}

	s.currentBlock = checkpoint.LastBlock
	s.logger.Info().
		Uint64("checkpoint", s.currentBlock).
		Str("hash", checkpoint.LastBlockHash).
		Msg("loaded checkpoint")

	// Get latest block
	latest, err := s.chain.GetLatestBlockNumber(ctx)
	if err != nil {
		return fmt.Errorf("failed to get latest block: %w", err)
	}
	s.latestBlock = latest
	chainHeight.Set(float64(latest))

	// Determine sync strategy
	behind := latest - s.confirmations - s.currentBlock
	if behind > s.batchSize*2 {
		s.logger.Info().
			Uint64("current", s.currentBlock).
			Uint64("latest", latest).
			Uint64("behind", behind).
			Msg("behind chain, starting backfill")
		return s.runBackfill(ctx)
	}

	s.logger.Info().
		Uint64("current", s.currentBlock).
		Uint64("latest", latest).
		Msg("near chain head, starting realtime sync")
	return s.runRealtime(ctx)
}

// runBackfill processes historical blocks with parallel workers.
func (s *Syncer) runBackfill(ctx context.Context) error {
	s.logger.Info().
		Int("workers", s.workers).
		Uint64("batch_size", s.batchSize).
		Msg("starting backfill mode")

	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}

		// Get latest block
		latest, err := s.chain.GetLatestBlockNumber(ctx)
		if err != nil {
			syncerErrors.WithLabelValues("get_latest_block").Inc()
			s.logger.Error().Err(err).Msg("failed to get latest block")
			time.Sleep(5 * time.Second)
			continue
		}

		s.latestBlock = latest
		chainHeight.Set(float64(latest))

		// Calculate safe head (with confirmations)
		safeHead := latest
		if latest > s.confirmations {
			safeHead = latest - s.confirmations
		}

		if s.currentBlock >= safeHead {
			s.logger.Info().
				Uint64("current", s.currentBlock).
				Uint64("safe_head", safeHead).
				Msg("caught up to chain head, switching to realtime")
			return s.runRealtime(ctx)
		}

		// Process batch
		batchEnd := s.currentBlock + s.batchSize
		if batchEnd > safeHead {
			batchEnd = safeHead
		}

		if err := s.processBatch(ctx, s.currentBlock+1, batchEnd); err != nil {
			syncerErrors.WithLabelValues("process_batch").Inc()
			s.logger.Error().
				Err(err).
				Uint64("from", s.currentBlock+1).
				Uint64("to", batchEnd).
				Msg("failed to process batch")
			time.Sleep(5 * time.Second)
			continue
		}

		// Update checkpoint
		block, err := s.chain.GetBlockByNumber(ctx, batchEnd)
		if err != nil {
			syncerErrors.WithLabelValues("get_block").Inc()
			s.logger.Error().Err(err).Uint64("block", batchEnd).Msg("failed to get block for checkpoint")
			time.Sleep(5 * time.Second)
			continue
		}

		if err := s.checkpoint.UpdateBlock(ctx, s.serviceName, batchEnd, block.Hash().Hex()); err != nil {
			syncerErrors.WithLabelValues("update_checkpoint").Inc()
			s.logger.Error().Err(err).Msg("failed to update checkpoint")
			time.Sleep(5 * time.Second)
			continue
		}

		s.currentBlock = batchEnd
		syncerHeight.Set(float64(s.currentBlock))
		blocksBehind.Set(float64(safeHead - s.currentBlock))

		s.logger.Info().
			Uint64("processed_to", batchEnd).
			Uint64("latest", latest).
			Uint64("behind", safeHead-batchEnd).
			Msg("processed batch")
	}
}

// runRealtime processes new blocks as they arrive.
func (s *Syncer) runRealtime(ctx context.Context) error {
	s.logger.Info().
		Dur("poll_interval", s.pollInterval).
		Uint64("confirmations", s.confirmations).
		Msg("starting realtime mode")

	ticker := time.NewTicker(s.pollInterval)
	defer ticker.Stop()

	for {
		select {
		case <-ctx.Done():
			return ctx.Err()
		case <-ticker.C:
			if err := s.syncToHead(ctx); err != nil {
				syncerErrors.WithLabelValues("sync_to_head").Inc()
				s.logger.Error().Err(err).Msg("failed to sync to head")
				s.isHealthy = false
				continue
			}
			s.isHealthy = true
		}
	}
}

// syncToHead syncs to the current chain head.
func (s *Syncer) syncToHead(ctx context.Context) error {
	// Get latest block
	latest, err := s.chain.GetLatestBlockNumber(ctx)
	if err != nil {
		return fmt.Errorf("failed to get latest block: %w", err)
	}

	s.latestBlock = latest
	chainHeight.Set(float64(latest))

	// Calculate safe head (with confirmations)
	safeHead := latest
	if latest > s.confirmations {
		safeHead = latest - s.confirmations
	}

	if s.currentBlock >= safeHead {
		// Already at head
		blocksBehind.Set(0)
		return nil
	}

	behind := safeHead - s.currentBlock
	blocksBehind.Set(float64(behind))

	// If too far behind, switch to backfill
	if behind > s.batchSize*2 {
		s.logger.Warn().
			Uint64("behind", behind).
			Msg("fell behind, switching to backfill mode")
		return s.runBackfill(ctx)
	}

	// Process blocks one at a time in realtime mode
	for block := s.currentBlock + 1; block <= safeHead; block++ {
		if err := s.processor.ProcessBlock(ctx, block); err != nil {
			return fmt.Errorf("failed to process block %d: %w", block, err)
		}

		// Update checkpoint
		header, err := s.chain.GetBlockByNumber(ctx, block)
		if err != nil {
			return fmt.Errorf("failed to get block %d: %w", block, err)
		}

		if err := s.checkpoint.UpdateBlock(ctx, s.serviceName, block, header.Hash().Hex()); err != nil {
			return fmt.Errorf("failed to update checkpoint: %w", err)
		}

		s.currentBlock = block
		syncerHeight.Set(float64(s.currentBlock))

		s.logger.Debug().
			Uint64("block", block).
			Uint64("latest", latest).
			Msg("processed block")
	}

	blocksBehind.Set(0)
	return nil
}

// processBatch processes a batch of blocks with parallel workers.
func (s *Syncer) processBatch(ctx context.Context, from, to uint64) error {
	if from > to {
		return fmt.Errorf("invalid range: from %d > to %d", from, to)
	}

	if s.workers == 1 {
		// Single-threaded processing
		return s.processor.ProcessBlockRange(ctx, from, to)
	}

	// Parallel processing with worker pool
	blockCount := to - from + 1
	blocksPerWorker := blockCount / uint64(s.workers)
	if blocksPerWorker == 0 {
		blocksPerWorker = 1
	}

	var wg sync.WaitGroup
	errChan := make(chan error, s.workers)

	for i := 0; i < s.workers; i++ {
		workerFrom := from + uint64(i)*blocksPerWorker
		workerTo := workerFrom + blocksPerWorker - 1

		// Last worker handles remainder
		if i == s.workers-1 {
			workerTo = to
		}

		if workerFrom > to {
			break
		}

		wg.Add(1)
		go func(from, to uint64) {
			defer wg.Done()
			if err := s.processor.ProcessBlockRange(ctx, from, to); err != nil {
				errChan <- err
			}
		}(workerFrom, workerTo)
	}

	// Wait for all workers
	wg.Wait()
	close(errChan)

	// Check for errors
	for err := range errChan {
		if err != nil {
			return err
		}
	}

	return nil
}

// GetStatus returns current syncer status.
func (s *Syncer) GetStatus() (current, latest uint64, healthy bool) {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.currentBlock, s.latestBlock, s.isHealthy
}

// Healthy returns true if the syncer is healthy.
func (s *Syncer) Healthy() bool {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.isHealthy
}
