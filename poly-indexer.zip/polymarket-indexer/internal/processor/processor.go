// Package processor handles block and event processing.
package processor

import (
	"context"
	"fmt"
	"time"

	"github.com/ethereum/go-ethereum/common"
	"github.com/ethereum/go-ethereum/core/types"
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
	"github.com/rs/zerolog"

	"github.com/0xkanth/polymarket-indexer/internal/chain"
	"github.com/0xkanth/polymarket-indexer/internal/handler"
	"github.com/0xkanth/polymarket-indexer/internal/nats"
	"github.com/0xkanth/polymarket-indexer/internal/router"
	"github.com/0xkanth/polymarket-indexer/pkg/models"
)

var (
	blocksProcessed = promauto.NewCounter(prometheus.CounterOpts{
		Name: "polymarket_blocks_processed_total",
		Help: "Total number of blocks processed",
	})

	eventsProcessed = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "polymarket_events_processed_total",
		Help: "Total number of events processed by type",
	}, []string{"event_type"})

	processingDuration = promauto.NewHistogram(prometheus.HistogramOpts{
		Name:    "polymarket_block_processing_duration_seconds",
		Help:    "Time taken to process a block",
		Buckets: prometheus.DefBuckets,
	})

	processingErrors = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "polymarket_processing_errors_total",
		Help: "Total number of processing errors",
	}, []string{"error_type"})
)

// Processor handles block and event processing.
type Processor struct {
	logger     zerolog.Logger
	chain      *chain.Client
	router     *router.Router
	publisher  *nats.Publisher
	contracts  []common.Address
	startBlock uint64
}

// Config holds processor configuration.
type Config struct {
	Contracts  []string // Contract addresses to monitor
	StartBlock uint64   // Block to start processing from
}

// New creates a new processor.
func New(
	logger zerolog.Logger,
	chain *chain.Client,
	publisher *nats.Publisher,
	cfg Config,
) (*Processor, error) {
	// Parse contract addresses
	contracts := make([]common.Address, len(cfg.Contracts))
	for i, addr := range cfg.Contracts {
		if !common.IsHexAddress(addr) {
			return nil, fmt.Errorf("invalid contract address: %s", addr)
		}
		contracts[i] = common.HexToAddress(addr)
	}

	// Create router and register handlers
	r := router.New(logger)

	// Register CTF Exchange handlers
	r.RegisterLogHandler(handler.OrderFilledSig, handler.HandleOrderFilled)
	r.RegisterLogHandler(handler.OrderCancelledSig, handler.HandleOrderCancelled)
	r.RegisterLogHandler(handler.TokenRegisteredSig, handler.HandleTokenRegistered)

	// Register Conditional Tokens handlers
	r.RegisterLogHandler(handler.TransferSingleSig, handler.HandleTransferSingle)
	r.RegisterLogHandler(handler.TransferBatchSig, handler.HandleTransferBatch)
	r.RegisterLogHandler(handler.ConditionPreparationSig, handler.HandleConditionPreparation)
	r.RegisterLogHandler(handler.ConditionResolutionSig, handler.HandleConditionResolution)
	r.RegisterLogHandler(handler.PositionSplitSig, handler.HandlePositionSplit)
	r.RegisterLogHandler(handler.PositionsMergeSig, handler.HandlePositionsMerge)

	return &Processor{
		logger:     logger.With().Str("component", "processor").Logger(),
		chain:      chain,
		router:     r,
		publisher:  publisher,
		contracts:  contracts,
		startBlock: cfg.StartBlock,
	}, nil
}

// ProcessBlock processes a single block.
func (p *Processor) ProcessBlock(ctx context.Context, blockNumber uint64) error {
	start := time.Now()
	defer func() {
		processingDuration.Observe(time.Since(start).Seconds())
	}()

	p.logger.Debug().Uint64("block", blockNumber).Msg("processing block")

	// Fetch block header
	block, err := p.chain.GetBlockByNumber(ctx, blockNumber)
	if err != nil {
		processingErrors.WithLabelValues("fetch_block").Inc()
		return fmt.Errorf("failed to get block %d: %w", blockNumber, err)
	}

	// Filter logs for monitored contracts
	logs, err := p.chain.FilterLogs(ctx, blockNumber, blockNumber, p.contracts)
	if err != nil {
		processingErrors.WithLabelValues("filter_logs").Inc()
		return fmt.Errorf("failed to filter logs for block %d: %w", blockNumber, err)
	}

	if len(logs) == 0 {
		p.logger.Debug().
			Uint64("block", blockNumber).
			Uint64("timestamp", block.Time()).
			Msg("no events in block")
		blocksProcessed.Inc()
		return nil
	}

	p.logger.Info().
		Uint64("block", blockNumber).
		Uint64("timestamp", block.Time()).
		Int("events", len(logs)).
		Msg("processing block with events")

	// Process each log
	for _, log := range logs {
		if err := p.processLog(ctx, log, block); err != nil {
			processingErrors.WithLabelValues("process_log").Inc()
			p.logger.Error().
				Err(err).
				Str("tx", log.TxHash.Hex()).
				Uint("log_index", log.Index).
				Msg("failed to process log")
			// Continue processing other logs
			continue
		}
	}

	blocksProcessed.Inc()
	return nil
}

// processLog processes a single log entry.
func (p *Processor) processLog(ctx context.Context, log types.Log, block *types.Header) error {
	if log.Removed {
		p.logger.Warn().
			Str("tx", log.TxHash.Hex()).
			Uint("log_index", log.Index).
			Msg("skipping removed log")
		return nil
	}

	// Route log to appropriate handler
	payload, err := p.router.RouteLog(ctx, log, block.Time)
	if err != nil {
		if err == router.ErrNoHandler {
			// Unknown event type, skip
			p.logger.Debug().
				Str("tx", log.TxHash.Hex()).
				Uint("log_index", log.Index).
				Str("topic0", log.Topics[0].Hex()).
				Msg("no handler for event")
			return nil
		}
		return fmt.Errorf("failed to route log: %w", err)
	}

	// Create event envelope
	event := models.Event{
		BlockNumber:     log.BlockNumber,
		BlockHash:       log.BlockHash.Hex(),
		BlockTimestamp:  block.Time,
		TransactionHash: log.TxHash.Hex(),
		LogIndex:        uint64(log.Index),
		ContractAddress: log.Address.Hex(),
		EventSignature:  log.Topics[0].Hex(),
		Payload:         payload,
	}

	// Publish to NATS
	eventName := p.getEventName(log.Topics[0])
	if err := p.publisher.Publish(ctx, eventName, log.Address.Hex(), event); err != nil {
		return fmt.Errorf("failed to publish event: %w", err)
	}

	eventsProcessed.WithLabelValues(eventName).Inc()

	p.logger.Debug().
		Str("event", eventName).
		Str("tx", log.TxHash.Hex()).
		Uint("log_index", log.Index).
		Msg("processed event")

	return nil
}

// getEventName returns a human-readable name for an event signature.
func (p *Processor) getEventName(sig common.Hash) string {
	switch sig {
	case handler.OrderFilledSig:
		return "OrderFilled"
	case handler.OrderCancelledSig:
		return "OrderCancelled"
	case handler.TokenRegisteredSig:
		return "TokenRegistered"
	case handler.TransferSingleSig:
		return "TransferSingle"
	case handler.TransferBatchSig:
		return "TransferBatch"
	case handler.ConditionPreparationSig:
		return "ConditionPreparation"
	case handler.ConditionResolutionSig:
		return "ConditionResolution"
	case handler.PositionSplitSig:
		return "PositionSplit"
	case handler.PositionsMergeSig:
		return "PositionsMerge"
	default:
		return "Unknown"
	}
}

// ProcessBlockRange processes a range of blocks.
func (p *Processor) ProcessBlockRange(ctx context.Context, from, to uint64) error {
	p.logger.Info().
		Uint64("from", from).
		Uint64("to", to).
		Uint64("count", to-from+1).
		Msg("processing block range")

	for block := from; block <= to; block++ {
		select {
		case <-ctx.Done():
			return ctx.Err()
		default:
		}

		if err := p.ProcessBlock(ctx, block); err != nil {
			return fmt.Errorf("failed to process block %d: %w", block, err)
		}
	}

	return nil
}
