// Main indexer service.
package main

import (
	"context"
	"fmt"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/prometheus/client_golang/prometheus/promhttp"

	"github.com/0xkanth/polymarket-indexer/internal/chain"
	"github.com/0xkanth/polymarket-indexer/internal/db"
	"github.com/0xkanth/polymarket-indexer/internal/nats"
	"github.com/0xkanth/polymarket-indexer/internal/processor"
	"github.com/0xkanth/polymarket-indexer/internal/syncer"
	"github.com/0xkanth/polymarket-indexer/internal/util"
)

const (
	serviceName = "polymarket-indexer"
)

func main() {
	// Initialize logger
	logger := util.InitLogger()
	logger.Info().Msg("starting polymarket indexer")

	// Load configuration
	cfg, err := util.InitConfig()
	if err != nil {
		logger.Fatal().Err(err).Msg("failed to load config")
	}

	// Update log level from config
	util.UpdateLogLevel(cfg.String("logging.level"))

	// Initialize chain client
	chainClient, err := chain.New(chain.Config{
		HTTPURL:     cfg.String("chain.http_url"),
		WSURL:       cfg.String("chain.ws_url"),
		ChainID:     cfg.Int64("chain.chain_id"),
		HTTPTimeout: cfg.Duration("chain.http_timeout"),
	})
	if err != nil {
		logger.Fatal().Err(err).Msg("failed to create chain client")
	}
	logger.Info().
		Str("http", cfg.String("chain.http_url")).
		Str("ws", cfg.String("chain.ws_url")).
		Int64("chain_id", cfg.Int64("chain.chain_id")).
		Msg("initialized chain client")

	// Initialize checkpoint store
	checkpointStore, err := db.NewCheckpointStore(cfg.String("db.checkpoint_path"))
	if err != nil {
		logger.Fatal().Err(err).Msg("failed to create checkpoint store")
	}
	defer checkpointStore.Close()
	logger.Info().
		Str("path", cfg.String("db.checkpoint_path")).
		Msg("initialized checkpoint store")

	// Initialize NATS publisher
	publisher, err := nats.NewPublisher(nats.PublisherConfig{
		URL:           cfg.String("nats.url"),
		StreamName:    cfg.String("nats.stream_name"),
		Subjects:      cfg.Strings("nats.subjects"),
		MaxAge:        cfg.Duration("nats.max_age"),
		Replicas:      cfg.Int("nats.replicas"),
		MaxMsgsPerSub: cfg.Int64("nats.max_msgs_per_subject"),
	})
	if err != nil {
		logger.Fatal().Err(err).Msg("failed to create nats publisher")
	}
	defer publisher.Close()
	logger.Info().
		Str("url", cfg.String("nats.url")).
		Str("stream", cfg.String("nats.stream_name")).
		Msg("initialized nats publisher")

	// Initialize processor
	proc, err := processor.New(
		logger,
		chainClient,
		publisher,
		processor.Config{
			Contracts:  cfg.Strings("indexer.contracts"),
			StartBlock: cfg.Uint64("indexer.start_block"),
		},
	)
	if err != nil {
		logger.Fatal().Err(err).Msg("failed to create processor")
	}
	logger.Info().
		Strs("contracts", cfg.Strings("indexer.contracts")).
		Uint64("start_block", cfg.Uint64("indexer.start_block")).
		Msg("initialized processor")

	// Initialize syncer
	sync := syncer.New(
		logger,
		chainClient,
		proc,
		checkpointStore,
		syncer.Config{
			ServiceName:   serviceName,
			StartBlock:    cfg.Uint64("indexer.start_block"),
			BatchSize:     cfg.Uint64("indexer.batch_size"),
			PollInterval:  cfg.Duration("indexer.poll_interval"),
			Confirmations: cfg.Uint64("indexer.confirmations"),
			Workers:       cfg.Int("indexer.workers"),
		},
	)
	logger.Info().
		Uint64("batch_size", cfg.Uint64("indexer.batch_size")).
		Dur("poll_interval", cfg.Duration("indexer.poll_interval")).
		Uint64("confirmations", cfg.Uint64("indexer.confirmations")).
		Int("workers", cfg.Int("indexer.workers")).
		Msg("initialized syncer")

	// Start metrics server
	metricsAddr := cfg.String("metrics.address")
	metricsServer := &http.Server{
		Addr:    metricsAddr,
		Handler: promhttp.Handler(),
	}

	go func() {
		logger.Info().Str("address", metricsAddr).Msg("starting metrics server")
		if err := metricsServer.ListenAndServe(); err != http.ErrServerClosed {
			logger.Error().Err(err).Msg("metrics server error")
		}
	}()

	// Start health check server
	healthAddr := cfg.String("health.address")
	healthServer := &http.Server{
		Addr:    healthAddr,
		Handler: http.HandlerFunc(healthCheckHandler(sync, publisher)),
	}

	go func() {
		logger.Info().Str("address", healthAddr).Msg("starting health check server")
		if err := healthServer.ListenAndServe(); err != http.ErrServerClosed {
			logger.Error().Err(err).Msg("health check server error")
		}
	}()

	// Create context for graceful shutdown
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()

	// Handle shutdown signals
	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, os.Interrupt, syscall.SIGTERM)

	// Start syncer in goroutine
	errChan := make(chan error, 1)
	go func() {
		errChan <- sync.Start(ctx)
	}()

	// Wait for shutdown signal or error
	select {
	case sig := <-sigChan:
		logger.Info().Str("signal", sig.String()).Msg("received shutdown signal")
	case err := <-errChan:
		if err != nil {
			logger.Error().Err(err).Msg("syncer error")
		}
	}

	// Graceful shutdown
	logger.Info().Msg("shutting down")
	cancel()

	// Shutdown metrics server
	shutdownCtx, shutdownCancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer shutdownCancel()

	if err := metricsServer.Shutdown(shutdownCtx); err != nil {
		logger.Error().Err(err).Msg("metrics server shutdown error")
	}

	if err := healthServer.Shutdown(shutdownCtx); err != nil {
		logger.Error().Err(err).Msg("health server shutdown error")
	}

	logger.Info().Msg("shutdown complete")
}

// healthCheckHandler returns a health check handler.
func healthCheckHandler(sync *syncer.Syncer, pub *nats.Publisher) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if !sync.Healthy() || !pub.Healthy() {
			w.WriteHeader(http.StatusServiceUnavailable)
			fmt.Fprintf(w, "unhealthy\n")
			return
		}

		current, latest, _ := sync.GetStatus()
		w.WriteHeader(http.StatusOK)
		fmt.Fprintf(w, "healthy\ncurrent: %d\nlatest: %d\nbehind: %d\n",
			current, latest, latest-current)
	}
}
