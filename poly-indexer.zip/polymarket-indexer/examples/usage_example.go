package examples
package main

import (
	"context"
	"fmt"
	"log"

	"github.com/yourusername/polymarket-indexer/pkg/config"
	"github.com/yourusername/polymarket-indexer/pkg/service"
)










































































}	fmt.Printf("\nFound %d events (showing first 5)\n", eventCount)	}		log.Fatalf("Iterator error: %v", err)	if err := iter.Error(); err != nil {	}		}			break		if eventCount >= 5 {		// Limit output for example				eventCount++		)			event.Taker.Hex(),			event.Maker.Hex(),			event.OrderHash,		fmt.Printf("OrderFilled: hash=%x, maker=%s, taker=%s\n",		event := iter.Event	for iter.Next() {	eventCount := 0	defer iter.Close()	}		log.Fatalf("Failed to filter events: %v", err)	if err != nil {	iter, err := svc.FilterOrderFilled(ctx, fromBlock, toBlock, nil, nil, nil)	fmt.Printf("Scanning events from block %d to %d\n", fromBlock, toBlock)	toBlock := fromBlock + 1000 // Scan first 1000 blocks	fromBlock := chainCfg.StartBlock	// Example: Filter events from startBlock	fmt.Printf("Starting to index from block %d...\n", chainCfg.StartBlock)	// Example: Use the startBlock for indexing	fmt.Println("CTF Service initialized successfully!")	defer svc.Close()	}		log.Fatalf("Failed to create CTF service: %v", err)	if err != nil {	svc, err := service.NewCTFService(ctx, chainCfg)	// Create CTF service	fmt.Println()	fmt.Printf("Confirmations: %d\n", chainCfg.Confirmations)	fmt.Printf("Block Time: %d seconds\n", chainCfg.BlockTime)	fmt.Printf("Start Block: %d\n", chainCfg.StartBlock)	fmt.Printf("ConditionalTokens: %s\n", chainCfg.GetConditionalTokensAddress().Hex())	fmt.Printf("CTFExchange: %s\n", chainCfg.GetCTFExchangeAddress().Hex())	fmt.Printf("RPC URLs: %v\n", chainCfg.RPCUrls)	fmt.Printf("Chain: %s (ID: %d)\n", chainCfg.Name, chainCfg.ChainID)	// Print configuration	}		log.Fatalf("Failed to get chain config: %v", err)	if err != nil {	chainCfg, err := cfg.GetChain(chainName)	chainName := "polygon" // or "polygon-fork" for testing	// Get chain configuration (polygon, polygon-fork, or mumbai)	}		log.Fatalf("Failed to load config: %v", err)	if err != nil {	cfg, err := config.LoadConfig("config/chains.json")	// Load configuration	ctx := context.Background()func main() {// Example of using the CTF service with config