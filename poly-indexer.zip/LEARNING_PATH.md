# Production Go EVM Indexer - Learning Path

## 🎯 Your Goal
Build production-grade blockchain indexer expertise for:
- EVM event indexing
- Complex ABI handling
- NATS integration
- TimescaleDB for time-series data
- Polymarket or prediction market use case

## ✅ Best Go Reference Projects Found

### 1. **eth-tracker** by Grassroots Economics ⭐ PRIMARY REFERENCE
**Location:** `reference/eth-tracker/`

**Why it's perfect:**
- ✅ **NATS JetStream integration** (exactly what you need!)
- ✅ Production-ready (10k blocks/min, 50MB RAM)
- ✅ Distributed deployment with deduplication
- ✅ Reorg handling
- ✅ Address filtering
- ✅ Event-driven architecture

**Key Architecture:**
```
eth-tracker/
├── cmd/service/              # Main entry point
├── internal/
│   ├── chain/                # EVM client
│   ├── syncer/               # Block syncing logic
│   ├── processor/            # Event processing
│   ├── handler/              # Event handlers (Transfer, Swap, etc.)
│   ├── pub/                  # NATS publisher
│   ├── cache/                # Address cache
│   └── backfill/             # Historical sync
├── pkg/
│   ├── event/                # Event definitions
│   └── router/               # Event routing
└── db/                       # Checkpoint persistence
```

**What you'll learn:**
- How to structure a production indexer
- NATS JetStream patterns
- Distributed deduplication
- Event handler patterns
- Checkpoint management

### 2. **evm-scanner** by 84hero ⭐ SECONDARY REFERENCE
**Location:** `reference/evm-scanner/`

**Why it's valuable:**
- ✅ **Multi-RPC load balancing & failover**
- ✅ Production-ready patterns
- ✅ Node-less architecture
- ✅ Extensible sinks (Postgres, Kafka, Webhooks)
- ✅ Excellent examples directory

**Key Architecture:**
```
evm-scanner/
├── pkg/
│   ├── scanner/              # Core scanner
│   ├── rpc/                  # RPC client pool
│   ├── decoder/              # ABI decoder
│   ├── sink/                 # Output adapters
│   ├── storage/              # Checkpoint storage
│   └── config/               # Configuration
├── examples/
│   ├── basic/
│   ├── postgres-integration/
│   ├── enterprise-mq/        # NATS/Kafka examples
│   ├── rpc-advanced/         # Multi-RPC patterns
│   └── custom-decoder/       # ABI handling
```

**What you'll learn:**
- RPC failover strategies
- Sink pattern for multiple outputs
- ABI decoding architecture
- Configuration patterns
- Production hardening

## 📚 Core Concepts (Same for ALL Indexers)

### 1. **Block Processing**
```
┌─────────────────────────────────────────┐
│  RPC Node                               │
│  ├─ getBlockNumber() → latest          │
│  ├─ getBlockByNumber(N)                │
│  └─ getLogs(filter)                    │
└─────────────────────────────────────────┘
           ↓
┌─────────────────────────────────────────┐
│  Syncer/Scanner                         │
│  ├─ Track last processed block         │
│  ├─ Fetch blocks sequentially          │
│  ├─ Handle reorgs                      │
│  └─ Checkpoint progress                │
└─────────────────────────────────────────┘
           ↓
┌─────────────────────────────────────────┐
│  Processor                              │
│  ├─ Parse transactions                 │
│  ├─ Decode event logs (ABI)            │
│  ├─ Filter by contract addresses       │
│  └─ Extract event data                 │
└─────────────────────────────────────────┘
           ↓
┌─────────────────────────────────────────┐
│  Output (NATS/DB)                       │
│  ├─ Publish to NATS streams            │
│  ├─ Store in TimescaleDB               │
│  └─ Ensure idempotency                 │
└─────────────────────────────────────────┘
```

### 2. **Reorg Handling**
- Always process blocks with confirmation depth
- Track canonical chain
- Detect uncle blocks
- Re-process affected blocks

### 3. **NATS Integration Patterns**
```go
// Publisher (from eth-tracker)
- JetStream with deduplication
- Subject hierarchy: TRACKER.{EventType}.{ContractAddress}
- Message ID for idempotency
- Persistent streams

// Consumer (you'll build)
- Subscribe to subjects
- Ack messages after processing
- Dead letter queue for failures
- Backpressure handling
```

### 4. **Database Schema (TimescaleDB)**
```sql
-- Events table (hypertable)
CREATE TABLE events (
    time TIMESTAMPTZ NOT NULL,
    block_number BIGINT,
    tx_hash TEXT,
    contract_address TEXT,
    event_name TEXT,
    event_data JSONB
);

-- Hypertable for time-series
SELECT create_hypertable('events', 'time');

-- Continuous aggregates
CREATE MATERIALIZED VIEW daily_volume
WITH (timescaledb.continuous) AS
SELECT time_bucket('1 day', time) AS day,
       contract_address,
       COUNT(*) as event_count,
       SUM((event_data->>'amount')::numeric) as volume
FROM events
GROUP BY day, contract_address;
```

## 🗺️ Your Learning Roadmap

### Phase 1: Study Reference Projects (Week 1-2)
**Study eth-tracker first (NATS integration):**
```bash
cd reference/eth-tracker

# Study these files in order:
1. cmd/service/main.go          # Entry point
2. internal/syncer/syncer.go    # Block syncing
3. internal/processor/*.go      # Event processing
4. internal/handler/*.go        # Event handlers
5. internal/pub/*.go            # NATS publisher
6. config.toml                  # Configuration
```

**Then study evm-scanner (RPC patterns):**
```bash
cd reference/evm-scanner

# Study these:
1. examples/basic/              # Start here
2. pkg/scanner/scanner.go       # Core logic
3. pkg/rpc/client.go            # RPC handling
4. pkg/decoder/decoder.go       # ABI decoding
5. examples/postgres-integration/
```

### Phase 2: Build Basic Indexer (Week 3-4)
Start with a simple token indexer:
```
Goal: Index USDC/USDT transfers on Polygon
- Connect to Polygon RPC
- Listen to Transfer events
- Parse event data
- Print to console
```

### Phase 3: Add NATS (Week 5)
```
Goal: Publish events to NATS
- Setup NATS JetStream locally
- Publish Transfer events
- Implement deduplication
- Build a consumer service
```

### Phase 4: Add TimescaleDB (Week 6)
```
Goal: Store events in TimescaleDB
- Setup TimescaleDB locally
- Create hypertables
- Consumer saves to DB
- Build aggregations
```

### Phase 5: Polymarket Indexer (Week 7-8)
```
Goal: Full Polymarket event indexing
- CTF Exchange events (OrderFilled)
- Conditional Token events
- Market creation tracking
- Trade volume aggregations
```

### Phase 6: Production Hardening (Week 9-10)
```
- Multi-RPC failover
- Monitoring (Prometheus)
- Graceful shutdown
- Error recovery
- Backfilling
- Rate limiting
```

## 🏗️ Project Structure for Your Implementation

```
polymarket-indexer/
├── cmd/
│   ├── indexer/              # Main indexer service
│   │   └── main.go
│   └── consumer/             # NATS consumer service
│       └── main.go
├── internal/
│   ├── chain/
│   │   ├── client.go         # EVM client wrapper
│   │   └── pool.go           # Connection pool
│   ├── indexer/
│   │   ├── syncer.go         # Block syncing
│   │   ├── processor.go      # Event processing
│   │   └── reorg.go          # Reorg handling
│   ├── nats/
│   │   ├── publisher.go      # NATS publisher
│   │   └── consumer.go       # NATS consumer
│   ├── db/
│   │   ├── repository.go     # Database interface
│   │   ├── events.go         # Event storage
│   │   └── aggregations.go  # Aggregation queries
│   └── config/
│       └── config.go         # Configuration
├── pkg/
│   └── models/
│       ├── event.go          # Event models
│       └── contract.go       # Contract models
├── contracts/
│   ├── abi/                  # ABI JSON files
│   └── bindings/             # Generated Go bindings
├── migrations/               # DB migrations
├── docker-compose.yml        # Local dev environment
├── config.yaml              # Configuration
└── Makefile                 # Build tasks
```

## 🔧 Tech Stack

### Core Dependencies
```bash
# EVM interaction
go get github.com/ethereum/go-ethereum

# NATS
go get github.com/nats-io/nats.go

# Database
go get github.com/jackc/pgx/v5

# Config
go get github.com/spf13/viper

# Logging
go get github.com/rs/zerolog

# Metrics
go get github.com/prometheus/client_golang
```

## 🎓 Key Learning Points

### 1. **Event Parsing with ABI**
```go
// Generate bindings from ABI
abigen --abi contracts/abi/CTFExchange.json \
       --pkg bindings \
       --type CTFExchange \
       --out contracts/bindings/ctf_exchange.go

// Use in code
contract, _ := bindings.NewCTFExchange(address, client)
iterator, _ := contract.FilterOrderFilled(...)
for iterator.Next() {
    event := iterator.Event
    // Process event
}
```

### 2. **NATS Deduplication Pattern**
```go
// Message ID prevents duplicates
msgID := fmt.Sprintf("%s-%d", txHash, logIndex)
js.Publish(subject, data, nats.MsgId(msgID))
```

### 3. **Checkpoint Management**
```go
// Always track progress
type Checkpoint struct {
    LastBlock      uint64
    LastBlockHash  string
    ProcessedAt    time.Time
}

// Resume from last checkpoint
checkpoint := db.GetLastCheckpoint()
startBlock := checkpoint.LastBlock + 1
```

## 📖 Resources to Study

1. **Go Ethereum (Geth) Docs**
   - https://geth.ethereum.org/docs/developers/geth-developer/dev-guide

2. **NATS JetStream**
   - https://docs.nats.io/nats-concepts/jetstream

3. **TimescaleDB**
   - https://docs.timescale.com/

4. **Polymarket Contracts**
   - CTF Exchange: `0x4bFb41d5B3570DeFd03C39a9A4D8dE6Bd8B8982E`
   - Conditional Tokens: `0x4D97DCd97eC945f40cF65F87097ACe5EA0476045`
   - Polygon RPC: https://polygon-rpc.com

## 🚀 Next Steps

1. **Study eth-tracker code** (focus on NATS integration)
2. **Run eth-tracker locally** to see it in action
3. **Build simple USDC indexer** as practice
4. **Add NATS** to your simple indexer
5. **Build Polymarket indexer** using the same patterns

## 💡 Pro Tips

1. **Start simple** - Don't build everything at once
2. **Copy patterns** - Both reference projects have battle-tested code
3. **Test locally first** - Use local NATS and TimescaleDB
4. **Handle errors properly** - Blockchain data is messy
5. **Monitor everything** - Metrics are crucial in production
6. **Read the code** - The reference projects are your best teachers

## 🤝 Need Help?

- eth-tracker issues: https://github.com/grassrootseconomics/eth-tracker/issues
- evm-scanner issues: https://github.com/84hero/evm-scanner/issues
- Go Ethereum: https://ethereum.stackexchange.com/

---

**Remember:** Whether indexing Polymarket, Uniswap, or any DeFi protocol, the core patterns remain the same. Master these patterns from the reference projects, and you can index anything!
